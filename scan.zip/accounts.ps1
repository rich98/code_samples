$adsi = [ADSI]"WinNT://$env:COMPUTERNAME"
$adsi.Children | where {$_.SchemaClassName -eq 'user'} | ForEach-Object {
    $username = $_.Name
    $groups = $_.Groups() | ForEach-Object {$_.GetType().InvokeMember("Name", 'GetProperty', $null, $_, $null)}
    $lastLogon = (Get-WmiObject -Class Win32_NetworkLoginProfile -Filter "Name='$env:COMPUTERNAME\\$username'" | Sort-Object -Property LastLogon -Descending | Select-Object -First 1).LastLogon
    $_ | Select-Object @{n='UserName';e={$username}}, @{n='Groups';e={$groups -join ';'}}, @{n='LastLogon';e={$lastLogon}}
}
