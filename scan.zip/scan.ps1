# Create an event trigger for Win32_VolumeChangeEvent
$eventQuery = "SELECT * FROM __InstanceOperationEvent WITHIN 5 WHERE TargetInstance ISA 'Win32_LogicalDisk'"

# Register the WMI event
Register-WmiEvent -Query $eventQuery -Action {
    # Check if the event type is '2' (indicating a new device)
    if ($event.SourceEventArgs.NewEvent.EventType -eq 2) {
        # Get the drive letter
        $driveLetter = $event.SourceEventArgs.NewEvent.TargetInstance.DeviceID

        # Run the Windows Defender scan and capture the output
        $scanResults = & 'C:\Program Files\Windows Defender\MpCmdRun.exe' -Scan -ScanType 3 -File $driveLetter -DisableRemediation

        # Write an entry to the Security event log
        $customMessage = "Scanned drive script: A USB drive was connected and scanned. Scan results: `n$scanResults"
        Write-EventLog -LogName Security -Source "USB Drive Scan Script" -EntryType Information -EventId 1000 -Message $customMessage
    }
}


