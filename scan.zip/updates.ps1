# Define the function to search for updates
function Check-ForUpdates {
    $updateSession = New-Object -ComObject Microsoft.Update.Session
    $updateSearcher = $updateSession.CreateUpdateSearcher()

    try {
        $searchResult = $updateSearcher.Search("IsInstalled=0 and Type='Software' and IsHidden=0")
    } catch {
        write-host "ERROR: $_"
        exit
    }

    if ($searchResult.Updates.Count -eq 0) {
        write-host "No new updates found."
        exit
    } else {
        write-host "$($searchResult.Updates.Count) updates found."
    }

    foreach ($update in $searchResult.Updates) {
        write-host "`n $($update.Title)"
    }
}

# Call the function to check for updates
Check-ForUpdates
